package com.healthc_ar.healthc_ar_services.HCAR_Element;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PatientElementController {

	@Autowired
	private PatientElementService patientElementService;

	// This gets every single patient object
	@RequestMapping("/patientobjects")
	public List<Element> getAllNetworkObjects() {
		return patientElementService.getAllPatientObjects();
	}
	
	// This a single patient object by "patientID"
	@GetMapping("/patientobjects/patientid/{patientID}")
	public Object findByPatientID(@PathVariable Long patientID) {
		return patientElementService.getPatientObject(patientID);
		
	}
	
	// PostReq for AUTHENTICATION & FACIAL RECOG. & SENTIMENT RECOG.
	
}
