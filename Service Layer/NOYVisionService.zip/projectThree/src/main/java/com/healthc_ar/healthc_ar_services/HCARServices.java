package com.healthc_ar.healthc_ar_services;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

// This is the entry point of the program
@SpringBootApplication
public class HCARServices {

	public static void main(String[] args) {
		System.out.print("Test");
		SpringApplication.run(HCARServices.class, args);
	}

}