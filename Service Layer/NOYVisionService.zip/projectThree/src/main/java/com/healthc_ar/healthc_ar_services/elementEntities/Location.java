package com.healthc_ar.healthc_ar_services.elementEntities;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.healthc_ar.healthc_ar_services.HCAR_Element.Element;

@Entity
@Table(name = "location")
public class Location {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Basic(optional = false)
	@Column(name = "locationid")
	private Long locationID;
	@Column(name = "state")
	private String state;
	@Column(name = "locid")
	private Long locID;
	
	@OneToOne(mappedBy = "location")
    private Element element;

	public Long getLocationID() {
		return locationID;
	}

	public String getState() {
		return state;
	}

	public Long getLocID() {
		return locID;
	}

	public void setLocationID(Long locationID) {
		this.locationID = locationID;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setLocID(Long locID) {
		this.locID = locID;
	}
}
