package com.healthc_ar.healthc_ar_services.elementEntities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.healthc_ar.healthc_ar_services.HCAR_Element.Element;

@Entity
@Table(name = "Appointments")
public class Appointments {

	@ManyToOne
	@JoinColumn(name = "patientid", nullable = false)
	@JsonIgnore
	private Element element;

	@Column(name = "appointmentreason")
	private String appointmentreason;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "appointmentid")
	private long appointmentID;

	public Appointments() {
	}

	public Appointments(Element element) {
		this.element = element;
	}

	public long getAppointmentID() {
		return appointmentID;
	}

	public String getAppointmentReason() {
		return appointmentreason;
	}

	public Element getElement() {
		return element;
	}

	public void setAppointmentID(long appointmentID) {
		this.appointmentID = appointmentID;
	}

	public void setAppointmentReason(String appointmentreason) {
		this.appointmentreason = appointmentreason;
	}

	public void setElement(Element element) {
		this.element = element;
	}
}