//
//  cellContentTableViewCell.swift
//  appTwo
//
//  Created by Peter Nguyen on 1/28/20.
//  Copyright © 2020 Peter Nguyen. All rights reserved.
//

import UIKit

class PatientNameCell: UITableViewCell {

    @IBOutlet weak var firstName: UILabel!
    @IBOutlet weak var patientIDNumber: UILabel!
    @IBOutlet weak var patientStateLoc: UILabel!
    @IBOutlet weak var appointmentReasonOne: UILabel!
    @IBOutlet weak var appointmentReasonTwo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
