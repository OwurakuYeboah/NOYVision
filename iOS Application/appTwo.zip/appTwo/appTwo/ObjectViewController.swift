//
//  ObjectViewController.swift
//  appTwo
//
//  Created by Peter Nguyen on 1/24/20.
//  Copyright © 2020 Peter Nguyen. All rights reserved.
//

import UIKit
import AVFoundation
import Vision

var patientIDJSON = 0
var fNameJSON = ""
var locationStateJSON = ""
var apptNumLabelJSON = 0
var apptReasonLabelOneJSON = ""
var apptReasonLabelTwoJSON = ""


class ObjectViewController: UIViewController {
    
    
    @IBOutlet var objectView: UIView!
    @IBOutlet weak var objectName: UILabel!
    
    var objectID: String!
    var productCatalog: [String: [String: Any]]!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Read the product catalog from the plist file into the dictionary.
        if let path = Bundle.main.path(forResource: "ObjectCatalog", ofType: "plist") {
            productCatalog = NSDictionary(contentsOfFile: path) as? [String: [String: Any]]
        }
    }
    
    func getJSON(serviceLayerURL: String) {
        struct jsonStruct: Decodable {
            let patientID: Int
            let firstName: String
            let location: Location
            let appointments: [Appointment]
        }
        struct Location: Decodable {
            let locationID: Int
            let state: String
            let locID: Int
        }
        
        struct Appointment: Decodable {
            let appointmentID: Int
            let appointmentReason: String
        }
        
        if let url = URL(string: serviceLayerURL) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    do {
                        let res = try JSONDecoder().decode(jsonStruct.self, from: data)
                        patientIDJSON = res.patientID
                        fNameJSON = res.firstName
                        locationStateJSON = res.location.state
                        apptNumLabelJSON = res.appointments[0].appointmentID
                        apptReasonLabelOneJSON = res.appointments[0].appointmentReason
                        apptReasonLabelTwoJSON = res.appointments[1].appointmentReason
                        //print(apptNumLabelJSON)
                    } catch let error {
                        print(error)
                    }
                    
                }
            }.resume()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Give the view rounded corners.
        objectView.layer.cornerRadius = 10
        objectView.layer.masksToBounds = true
        
        if objectID != nil {
            guard productCatalog[objectID] != nil else {
                return
            }
            objectName.text = productCatalog[objectID]?["label"] as? String
        }
        
        if objectID == "Peter" {
            getJSON(serviceLayerURL: "http://63369caa.ngrok.io/patientobjects/patientid/1")
        }
        if objectID == "Ray" {
            getJSON(serviceLayerURL: "http://63369caa.ngrok.io/patientobjects/patientid/2")
        }
        if objectID == "Ayesha" {
            getJSON(serviceLayerURL: "http://63369caa.ngrok.io/patientobjects/patientid/1")
        }
        if objectID == "Sharvita" {
            getJSON(serviceLayerURL: "http://63369caa.ngrok.io/patientobjects/patientid/2")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is PatientTableViewController {
            let vc = segue.destination as? PatientTableViewController
            vc?.PatientID = objectID
            vc?.PatID = patientIDJSON
            vc?.PatStateLoc = locationStateJSON
            vc?.PatAppReasonOne = apptReasonLabelOneJSON
            vc?.PatAppReasonTwo = apptReasonLabelTwoJSON
        }
    }
}
